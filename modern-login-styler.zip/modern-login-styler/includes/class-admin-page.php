<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MLS_Admin_Page {

	public function init() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
	}

	public function menu() {
		add_options_page(
			esc_html__( 'Modern Login Styler', 'modern-login-styler' ),
			esc_html__( 'Modern Login Styler', 'modern-login-styler' ),
			'manage_options',
			'modern-login-styler',
			array( $this, 'render' )
		);
	}

	public function enqueue( $hook ) {
		if ( 'settings_page_modern-login-styler' !== $hook ) {
			return;
		}

		// Needed for wp.media modal. [web:90]
		wp_enqueue_media(); // [web:90]

		// WP color picker. [web:21]
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wp-color-picker' );

		wp_enqueue_style(
			'mls-admin',
			MLS_URL . 'assets/admin/themejr-admin.css',
			array(),
			MLS_VERSION
		);

		wp_enqueue_script(
			'mls-admin',
			MLS_URL . 'assets/admin/themejr-admin.js',
			array( 'jquery', 'wp-color-picker' ),
			MLS_VERSION,
			true
		);
	}

	public function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// Prepare previews from saved attachment IDs (fixes "preview disappears after save"). [web:71]
		$bg_id  = (int) mls_get_option( 'bg_image_id', 0 );
		$bg_url = $bg_id ? wp_get_attachment_image_url( $bg_id, 'medium' ) : ''; // [web:71]
		$bg_url = $bg_url ? esc_url( $bg_url ) : '';

		$logo_id  = (int) mls_get_option( 'logo_image_id', 0 );
		$logo_url = $logo_id ? wp_get_attachment_image_url( $logo_id, 'medium' ) : ''; // [web:71]
		$logo_url = $logo_url ? esc_url( $logo_url ) : '';
		?>
		<div class="wrap mls-admin">
			<h1><?php echo esc_html__( 'Modern Login Styler', 'modern-login-styler' ); ?></h1>

			<form method="post" action="options.php">
				<?php settings_fields( 'mls_settings_group' ); ?>

				<div class="mls-grid">

					<div class="mls-card">
						<h2><?php echo esc_html__( 'Background', 'modern-login-styler' ); ?></h2>

						<p>
							<label>
								<input type="radio" name="<?php echo esc_attr( MLS_Settings::OPTION_KEY ); ?>[bg_type]" value="color" <?php checked( mls_get_option( 'bg_type', 'color' ), 'color' ); ?> />
								<?php echo esc_html__( 'Color', 'modern-login-styler' ); ?>
							</label>
							&nbsp;&nbsp;
							<label>
								<input type="radio" name="<?php echo esc_attr( MLS_Settings::OPTION_KEY ); ?>[bg_type]" value="image" <?php checked( mls_get_option( 'bg_type', 'color' ), 'image' ); ?> />
								<?php echo esc_html__( 'Image', 'modern-login-styler' ); ?>
							</label>
						</p>

						<p>
							<label><?php echo esc_html__( 'Background color', 'modern-login-styler' ); ?></label><br/>
							<input class="mls-color" type="text" name="<?php echo esc_attr( MLS_Settings::OPTION_KEY ); ?>[bg_color]" value="<?php echo esc_attr( mls_get_option( 'bg_color', '#f3f5f8' ) ); ?>" />
						</p>

						<p>
							<label><?php echo esc_html__( 'Background image', 'modern-login-styler' ); ?></label><br/>

							<input
								type="hidden"
								class="mls-media-id"
								name="<?php echo esc_attr( MLS_Settings::OPTION_KEY ); ?>[bg_image_id]"
								value="<?php echo esc_attr( (string) $bg_id ); ?>"
							/>

							<button type="button" class="button mls-media-pick" data-target="bg">
								<?php echo esc_html__( 'Choose image', 'modern-login-styler' ); ?>
							</button>

							<button type="button" class="button mls-media-clear" data-target="bg">
								<?php echo esc_html__( 'Remove', 'modern-login-styler' ); ?>
							</button>

							<div class="mls-media-preview" data-preview="bg">
								<?php if ( $bg_url ) : ?>
									<img src="<?php echo esc_url( $bg_url ); ?>" alt="" />
								<?php endif; ?>
							</div>
						</p>

						<p>
							<label><?php echo esc_html__( 'Overlay color (rgba)', 'modern-login-styler' ); ?></label><br/>
							<input
								type="text"
								class="regular-text"
								name="<?php echo esc_attr( MLS_Settings::OPTION_KEY ); ?>[bg_overlay_color]"
								value="<?php echo esc_attr( mls_get_option( 'bg_overlay_color', 'rgba(0,0,0,0.35)' ) ); ?>"
							/>
						</p>
					</div>

					<div class="mls-card">
						<h2><?php echo esc_html__( 'Form', 'modern-login-styler' ); ?></h2>

						<p>
							<label><?php echo esc_html__( 'Form background', 'modern-login-styler' ); ?></label><br/>
							<input class="mls-color" type="text" name="<?php echo esc_attr( MLS_Settings::OPTION_KEY ); ?>[form_bg]" value="<?php echo esc_attr( mls_get_option( 'form_bg', '#ffffff' ) ); ?>" />
						</p>

						<p>
							<label><?php echo esc_html__( 'Form border', 'modern-login-styler' ); ?></label><br/>
							<input class="mls-color" type="text" name="<?php echo esc_attr( MLS_Settings::OPTION_KEY ); ?>[form_border]" value="<?php echo esc_attr( mls_get_option( 'form_border', '#e6e8ee' ) ); ?>" />
						</p>

						<p>
							<label><?php echo esc_html__( 'Border radius (0-30)', 'modern-login-styler' ); ?></label><br/>
							<input
								type="number"
								min="0"
								max="30"
								name="<?php echo esc_attr( MLS_Settings::OPTION_KEY ); ?>[form_radius]"
								value="<?php echo esc_attr( (string) mls_get_option( 'form_radius', 14 ) ); ?>"
							/>
						</p>

						<p>
							<label><?php echo esc_html__( 'Form width (280-520)', 'modern-login-styler' ); ?></label><br/>
							<input
								type="number"
								min="280"
								max="520"
								name="<?php echo esc_attr( MLS_Settings::OPTION_KEY ); ?>[form_width]"
								value="<?php echo esc_attr( (string) mls_get_option( 'form_width', 360 ) ); ?>"
							/>
						</p>
					</div>

					<div class="mls-card">
						<h2><?php echo esc_html__( 'Typography & Button', 'modern-login-styler' ); ?></h2>

						<p>
							<label><?php echo esc_html__( 'Text color', 'modern-login-styler' ); ?></label><br/>
							<input class="mls-color" type="text" name="<?php echo esc_attr( MLS_Settings::OPTION_KEY ); ?>[text_color]" value="<?php echo esc_attr( mls_get_option( 'text_color', '#1f2937' ) ); ?>" />
						</p>

						<p>
							<label><?php echo esc_html__( 'Label color', 'modern-login-styler' ); ?></label><br/>
							<input class="mls-color" type="text" name="<?php echo esc_attr( MLS_Settings::OPTION_KEY ); ?>[label_color]" value="<?php echo esc_attr( mls_get_option( 'label_color', '#374151' ) ); ?>" />
						</p>

						<p>
							<label><?php echo esc_html__( 'Link color', 'modern-login-styler' ); ?></label><br/>
							<input class="mls-color" type="text" name="<?php echo esc_attr( MLS_Settings::OPTION_KEY ); ?>[link_color]" value="<?php echo esc_attr( mls_get_option( 'link_color', '#2563eb' ) ); ?>" />
						</p>

						<hr/>

						<p>
							<label><?php echo esc_html__( 'Button background', 'modern-login-styler' ); ?></label><br/>
							<input class="mls-color" type="text" name="<?php echo esc_attr( MLS_Settings::OPTION_KEY ); ?>[btn_bg]" value="<?php echo esc_attr( mls_get_option( 'btn_bg', '#2563eb' ) ); ?>" />
						</p>

						<p>
							<label><?php echo esc_html__( 'Button text', 'modern-login-styler' ); ?></label><br/>
							<input class="mls-color" type="text" name="<?php echo esc_attr( MLS_Settings::OPTION_KEY ); ?>[btn_text]" value="<?php echo esc_attr( mls_get_option( 'btn_text', '#ffffff' ) ); ?>" />
						</p>

						<p>
							<label><?php echo esc_html__( 'Button hover background', 'modern-login-styler' ); ?></label><br/>
							<input class="mls-color" type="text" name="<?php echo esc_attr( MLS_Settings::OPTION_KEY ); ?>[btn_bg_hover]" value="<?php echo esc_attr( mls_get_option( 'btn_bg_hover', '#1d4ed8' ) ); ?>" />
						</p>
					</div>

					<div class="mls-card">
						<h2><?php echo esc_html__( 'Logo', 'modern-login-styler' ); ?></h2>

						<p>
							<label>
								<input type="radio" name="<?php echo esc_attr( MLS_Settings::OPTION_KEY ); ?>[logo_type]" value="image" <?php checked( mls_get_option( 'logo_type', 'image' ), 'image' ); ?> />
								<?php echo esc_html__( 'Image', 'modern-login-styler' ); ?>
							</label>
							&nbsp;&nbsp;
							<label>
								<input type="radio" name="<?php echo esc_attr( MLS_Settings::OPTION_KEY ); ?>[logo_type]" value="text" <?php checked( mls_get_option( 'logo_type', 'image' ), 'text' ); ?> />
								<?php echo esc_html__( 'Text', 'modern-login-styler' ); ?>
							</label>
						</p>

						<p>
							<label><?php echo esc_html__( 'Logo image', 'modern-login-styler' ); ?></label><br/>

							<input
								type="hidden"
								class="mls-media-id"
								name="<?php echo esc_attr( MLS_Settings::OPTION_KEY ); ?>[logo_image_id]"
								value="<?php echo esc_attr( (string) $logo_id ); ?>"
							/>

							<button type="button" class="button mls-media-pick" data-target="logo">
								<?php echo esc_html__( 'Choose logo', 'modern-login-styler' ); ?>
							</button>

							<button type="button" class="button mls-media-clear" data-target="logo">
								<?php echo esc_html__( 'Remove', 'modern-login-styler' ); ?>
							</button>

							<div class="mls-media-preview" data-preview="logo">
								<?php if ( $logo_url ) : ?>
									<img src="<?php echo esc_url( $logo_url ); ?>" alt="" />
								<?php endif; ?>
							</div>
						</p>

						<p>
							<label><?php echo esc_html__( 'Logo text', 'modern-login-styler' ); ?></label><br/>
							<input
								type="text"
								class="regular-text"
								name="<?php echo esc_attr( MLS_Settings::OPTION_KEY ); ?>[logo_text]"
								value="<?php echo esc_attr( mls_get_option( 'logo_text', '' ) ); ?>"
							/>
						</p>

						<p>
							<label><?php echo esc_html__( 'Logo link URL', 'modern-login-styler' ); ?></label><br/>
							<input
								type="url"
								class="regular-text"
								name="<?php echo esc_attr( MLS_Settings::OPTION_KEY ); ?>[logo_url]"
								value="<?php echo esc_attr( mls_get_option( 'logo_url', home_url( '/' ) ) ); ?>"
							/>
						</p>

						<p>
							<label><?php echo esc_html__( 'Logo title attribute', 'modern-login-styler' ); ?></label><br/>
							<input
								type="text"
								class="regular-text"
								name="<?php echo esc_attr( MLS_Settings::OPTION_KEY ); ?>[logo_title]"
								value="<?php echo esc_attr( mls_get_option( 'logo_title', '' ) ); ?>"
							/>
						</p>
					</div>

					<div class="mls-card mls-card--full">
						<h2><?php echo esc_html__( 'Custom CSS', 'modern-login-styler' ); ?></h2>

						<p>
							<label>
								<input type="checkbox" name="<?php echo esc_attr( MLS_Settings::OPTION_KEY ); ?>[enable_custom_css]" value="1" <?php checked( (int) mls_get_option( 'enable_custom_css', 0 ), 1 ); ?> />
								<?php echo esc_html__( 'Enable custom CSS (sanitized)', 'modern-login-styler' ); ?>
							</label>
						</p>

						<textarea class="large-text code" rows="6" name="<?php echo esc_attr( MLS_Settings::OPTION_KEY ); ?>[custom_css]"><?php echo esc_textarea( (string) mls_get_option( 'custom_css', '' ) ); ?></textarea>
					</div>

				</div>

				<?php submit_button( esc_html__( 'Save Changes', 'modern-login-styler' ) ); ?>
			</form>

			<p>
				<a class="button" href="<?php echo esc_url( wp_login_url() ); ?>" target="_blank" rel="noopener">
					<?php echo esc_html__( 'Preview login page', 'modern-login-styler' ); ?>
				</a>
			</p>
		</div>
		<?php
	}
}