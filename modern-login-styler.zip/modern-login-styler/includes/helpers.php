<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function mls_get_option( $key, $default = '' ) {
	$opts = get_option( MLS_Settings::OPTION_KEY, array() );
	$opts = is_array( $opts ) ? $opts : array();

	return array_key_exists( $key, $opts ) ? $opts[ $key ] : $default;
}
