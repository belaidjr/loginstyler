<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once MLS_DIR . 'includes/helpers.php';
require_once MLS_DIR . 'includes/class-settings.php';
require_once MLS_DIR . 'includes/class-admin-page.php';
require_once MLS_DIR . 'includes/class-login-styles.php';

final class MLS_Plugin {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function init() {
		load_plugin_textdomain( 'modern-login-styler', false, dirname( plugin_basename( MLS_FILE ) ) . '/languages' );

		( new MLS_Settings() )->init();
		( new MLS_Admin_Page() )->init();
		( new MLS_Login_Styles() )->init();
	}
}
