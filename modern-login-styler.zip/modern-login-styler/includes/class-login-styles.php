<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MLS_Login_Styles {

	public function init() {
		add_action( 'login_enqueue_scripts', array( $this, 'enqueue' ) );
		add_filter( 'login_headerurl', array( $this, 'logo_url' ) );
		add_filter( 'login_headertext', array( $this, 'logo_title' ) );
	}

	public function enqueue() {
		wp_enqueue_style(
			'mls-login',
			MLS_URL . 'assets/public/css/themejr-login.css',
			array(),
			MLS_VERSION
		);

		// Pass settings to CSS via inline variables.
		$css = $this->build_css_variables();
		if ( '' !== $css ) {
			wp_add_inline_style( 'mls-login', $css );
		}

		wp_enqueue_script(
			'mls-login',
			MLS_URL . 'assets/public/js/themejr-login.js',
			array(),
			MLS_VERSION,
			true
		);
	}

	private function build_css_variables() {
		$bg_type          = mls_get_option( 'bg_type', 'color' );
		$bg_color         = mls_get_option( 'bg_color', '#f3f5f8' );
		$bg_image_id      = (int) mls_get_option( 'bg_image_id', 0 );
		$bg_overlay_color = mls_get_option( 'bg_overlay_color', 'rgba(0,0,0,0.35)' );

		$form_bg     = mls_get_option( 'form_bg', '#ffffff' );
		$form_border = mls_get_option( 'form_border', '#e6e8ee' );
		$form_radius = (int) mls_get_option( 'form_radius', 14 );
		$form_width  = (int) mls_get_option( 'form_width', 360 );

		$text_color  = mls_get_option( 'text_color', '#1f2937' );
		$label_color = mls_get_option( 'label_color', '#374151' );
		$link_color  = mls_get_option( 'link_color', '#2563eb' );

		$btn_bg       = mls_get_option( 'btn_bg', '#2563eb' );
		$btn_text     = mls_get_option( 'btn_text', '#ffffff' );
		$btn_bg_hover = mls_get_option( 'btn_bg_hover', '#1d4ed8' );

		$logo_type     = mls_get_option( 'logo_type', 'image' );
		$logo_image_id = (int) mls_get_option( 'logo_image_id', 0 );
		$logo_text     = mls_get_option( 'logo_text', '' );

		$bg_image_url = '';
		if ( 'image' === $bg_type && $bg_image_id > 0 ) {
			$bg_image_url = wp_get_attachment_image_url( $bg_image_id, 'full' );
			$bg_image_url = $bg_image_url ? esc_url_raw( $bg_image_url ) : '';
		}

		$logo_url = '';
		if ( 'image' === $logo_type && $logo_image_id > 0 ) {
			$logo_url = wp_get_attachment_image_url( $logo_image_id, 'full' );
			$logo_url = $logo_url ? esc_url_raw( $logo_url ) : '';
		}

		$vars = array(
			'--mls-bg-color'         => $bg_color,
			'--mls-bg-image'         => $bg_image_url ? 'url("' . $bg_image_url . '")' : 'none',
			'--mls-bg-overlay'       => $bg_overlay_color,
			'--mls-form-bg'          => $form_bg,
			'--mls-form-border'      => $form_border,
			'--mls-form-radius'      => $form_radius . 'px',
			'--mls-form-width'       => $form_width . 'px',
			'--mls-text-color'       => $text_color,
			'--mls-label-color'      => $label_color,
			'--mls-link-color'       => $link_color,
			'--mls-btn-bg'           => $btn_bg,
			'--mls-btn-text'         => $btn_text,
			'--mls-btn-bg-hover'     => $btn_bg_hover,
			'--mls-logo-image'       => $logo_url ? 'url("' . $logo_url . '")' : 'none',
			'--mls-logo-text'        => $logo_text,
		);

		$lines = array();
		$lines[] = ':root{';
		foreach ( $vars as $k => $v ) {
			$lines[] = $k . ':' . $v . ';';
		}
		$lines[] = '}';

		// Optional custom CSS (sanitized earlier).
		if ( (int) mls_get_option( 'enable_custom_css', 0 ) === 1 ) {
			$custom = (string) mls_get_option( 'custom_css', '' );
			if ( '' !== trim( $custom ) ) {
				$lines[] = $custom;
			}
		}

		return implode( "\n", $lines );
	}

	public function logo_url( $url ) {
		$custom = (string) mls_get_option( 'logo_url', home_url( '/' ) );
		return $custom ? esc_url( $custom ) : $url;
	}

	public function logo_title( $title ) {
		$custom = (string) mls_get_option( 'logo_title', '' );
		return '' !== $custom ? esc_attr( $custom ) : $title;
	}
}
