<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MLS_Settings {

	const OPTION_KEY = 'mls_settings';

	public function init() {
		add_action( 'admin_init', array( $this, 'register' ) );
		$this->maybe_defaults();
	}

	private function maybe_defaults() {
		if ( null !== get_option( self::OPTION_KEY, null ) ) {
			return;
		}

		add_option(
			self::OPTION_KEY,
			array(
				// Background.
				'bg_type'          => 'color', // color|image.
				'bg_color'         => '#f3f5f8',
				'bg_image_id'      => 0,
				'bg_overlay_color' => 'rgba(0,0,0,0.35)',

				// Form.
				'form_bg'          => '#ffffff',
				'form_border'      => '#e6e8ee',
				'form_radius'      => 14,

				// Text.
				'text_color'       => '#1f2937',
				'label_color'      => '#374151',
				'link_color'       => '#2563eb',

				// Button.
				'btn_bg'           => '#2563eb',
				'btn_text'         => '#ffffff',
				'btn_bg_hover'     => '#1d4ed8',

				// Logo.
				'logo_type'        => 'image', // image|text.
				'logo_image_id'    => 0,
				'logo_text'        => '',
				'logo_url'         => home_url( '/' ),
				'logo_title'       => '',

				// Layout.
				'form_width'       => 360,
				'enable_custom_css'=> 0,
				'custom_css'       => '',
			),
			'',
			false
		);
	}

	public function register() {
		register_setting(
			'mls_settings_group',
			self::OPTION_KEY,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( $this, 'sanitize' ),
				'default'           => array(),
			)
		);
	}

	public function sanitize( $input ) {
		$input = is_array( $input ) ? $input : array();
		$out   = array();

		$out['bg_type']  = ( isset( $input['bg_type'] ) && in_array( $input['bg_type'], array( 'color', 'image' ), true ) ) ? $input['bg_type'] : 'color';
		$out['bg_color'] = isset( $input['bg_color'] ) ? sanitize_hex_color( $input['bg_color'] ) : '#f3f5f8';
		if ( empty( $out['bg_color'] ) ) {
			$out['bg_color'] = '#f3f5f8';
		}

		$out['bg_image_id'] = isset( $input['bg_image_id'] ) ? absint( $input['bg_image_id'] ) : 0;

		// Allow rgba() overlay as text (basic whitelist).
		$overlay = isset( $input['bg_overlay_color'] ) ? sanitize_text_field( $input['bg_overlay_color'] ) : 'rgba(0,0,0,0.35)';
		$out['bg_overlay_color'] = preg_match( '/^rgba\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*,\s*(0(\.\d+)?|1(\.0)?)\s*\)$/', $overlay ) ? $overlay : 'rgba(0,0,0,0.35)';

		$out['form_bg']     = isset( $input['form_bg'] ) ? sanitize_hex_color( $input['form_bg'] ) : '#ffffff';
		$out['form_border'] = isset( $input['form_border'] ) ? sanitize_hex_color( $input['form_border'] ) : '#e6e8ee';
		$out['form_radius'] = isset( $input['form_radius'] ) ? max( 0, min( 30, absint( $input['form_radius'] ) ) ) : 14;

		$out['text_color']  = isset( $input['text_color'] ) ? sanitize_hex_color( $input['text_color'] ) : '#1f2937';
		$out['label_color'] = isset( $input['label_color'] ) ? sanitize_hex_color( $input['label_color'] ) : '#374151';
		$out['link_color']  = isset( $input['link_color'] ) ? sanitize_hex_color( $input['link_color'] ) : '#2563eb';

		$out['btn_bg']       = isset( $input['btn_bg'] ) ? sanitize_hex_color( $input['btn_bg'] ) : '#2563eb';
		$out['btn_text']     = isset( $input['btn_text'] ) ? sanitize_hex_color( $input['btn_text'] ) : '#ffffff';
		$out['btn_bg_hover'] = isset( $input['btn_bg_hover'] ) ? sanitize_hex_color( $input['btn_bg_hover'] ) : '#1d4ed8';

		$out['logo_type']     = ( isset( $input['logo_type'] ) && in_array( $input['logo_type'], array( 'image', 'text' ), true ) ) ? $input['logo_type'] : 'image';
		$out['logo_image_id'] = isset( $input['logo_image_id'] ) ? absint( $input['logo_image_id'] ) : 0;
		$out['logo_text']     = isset( $input['logo_text'] ) ? sanitize_text_field( $input['logo_text'] ) : '';
		$out['logo_url']      = isset( $input['logo_url'] ) ? esc_url_raw( $input['logo_url'] ) : home_url( '/' );
		$out['logo_title']    = isset( $input['logo_title'] ) ? sanitize_text_field( $input['logo_title'] ) : '';

		$out['form_width'] = isset( $input['form_width'] ) ? max( 280, min( 520, absint( $input['form_width'] ) ) ) : 360;

		$out['enable_custom_css'] = empty( $input['enable_custom_css'] ) ? 0 : 1;
		$out['custom_css']        = isset( $input['custom_css'] ) ? wp_strip_all_tags( (string) $input['custom_css'], true ) : '';

		// Normalize empty hex.
		foreach ( array( 'form_bg','form_border','text_color','label_color','link_color','btn_bg','btn_text','btn_bg_hover' ) as $hex_key ) {
			if ( empty( $out[ $hex_key ] ) ) {
				$out[ $hex_key ] = '#000000';
			}
		}

		return $out;
	}
}
