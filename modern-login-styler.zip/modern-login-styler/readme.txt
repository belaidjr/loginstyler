=== Modern Custom Login – Register – Forgot Password ===
Contributors: yourname
Tags: login, register, ajax, security
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Modern custom login, registration and forgot password forms with AJAX.

== Description ==
Provides modern UI forms via shortcodes:
- [modern_login]
- [modern_register]
- [modern_forgot_password]

== Installation ==
1. Upload the plugin folder to the `/wp-content/plugins/` directory.
2. Activate the plugin from the 'Plugins' menu.
3. Add shortcodes to any page.

== Frequently Asked Questions ==
= Does it support translations? =
Yes, all strings are translation-ready.

== Changelog ==
= 1.0.0 =
- Initial release.

