(function () {
	'use strict';
	// The body class is added via PHP inline, but keep JS empty for now (no need).
})();
