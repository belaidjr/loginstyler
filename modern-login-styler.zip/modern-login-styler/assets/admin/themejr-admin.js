(function ($) {
	'use strict';

	function initColorPickers() {
		$('.mls-color').wpColorPicker();
	}

	function mediaFrame(onSelect) {
		var frame = wp.media({
			title: 'Select image',
			button: { text: 'Use this image' },
			multiple: false
		});
		frame.on('select', function () {
			var att = frame.state().get('selection').first().toJSON();
			onSelect(att);
		});
		return frame;
	}

	function setPreview(target, url) {
		var $preview = $('.mls-media-preview[data-preview="' + target + '"]');
		if (!url) {
			$preview.html('');
			return;
		}
		$preview.html('<img src="' + url + '" alt="" />');
	}

	$(function () {
		initColorPickers();

		$(document).on('click', '.mls-media-pick', function (e) {
			e.preventDefault();
			var target = $(this).data('target');

			var frame = mediaFrame(function (att) {
				var $id = $('input.mls-media-id[name*="[' + (target === 'bg' ? 'bg_image_id' : 'logo_image_id') + ']"]');
				$id.val(att.id);
				setPreview(target, att.url);
			});

			frame.open();
		});

		$(document).on('click', '.mls-media-clear', function (e) {
			e.preventDefault();
			var target = $(this).data('target');
			var $id = $('input.mls-media-id[name*="[' + (target === 'bg' ? 'bg_image_id' : 'logo_image_id') + ']"]');
			$id.val('0');
			setPreview(target, '');
		});
	});
})(jQuery);
